package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepository repository;

	@PostMapping("/addUser")
	public String saveUser(@RequestBody Employee emp) {
		if (emp != null) {
			repository.save(emp);
			return "User with id " + emp.getId() + " has been added";
		} else {
			return "Input cannot be null";
		}
	}
	
	@GetMapping("/findAllUsers")
	public List getUsers() {
		return (List) repository.findAll();
	}

	@DeleteMapping("/delete/{id}")
	public String deleteUser(@PathVariable int id) {
			repository.deleteById(id);
			return "User with id " + id + "has been deleted";
		}

	@PutMapping("/update")
	public String updateBook(@RequestBody Employee emp) {
		if(emp!=null) {
			repository.save(emp);
			return "Updated";
		}
		else {
			return "Input cannot be null";
		}
	}
	}